var searchData=
[
  ['listentries',['listEntries',['../structcandidate_list.html#ab974beb5a5a671632174c48785bccd7c',1,'candidateList']]]
];
