var searchData=
[
  ['variableaffected',['variableAffected',['../structrule.html#a7172407a07da51743953b74f4e483c8b',1,'rule']]],
  ['variablevalues',['variableValues',['../structcandidate_solution.html#a9e61e35b326c4646ada6f4157b1855b0',1,'candidateSolution']]]
];
