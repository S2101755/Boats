var searchData=
[
  ['rule',['rule',['../structrule.html',1,'']]]
];
