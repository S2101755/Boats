var searchData=
[
  ['train',['train',['../_train_and_test_8h.html#ac4fd3e386abc86b08957b933dffa4e8a',1,'TrainAndTest.c']]]
];
