var dir_568959b31ed803cac90ce8316a329c81 =
[
    [ "Example_main.c", "_example__main_8c_source.html", null ],
    [ "ExampleData.h", "_example_data_8h_source.html", null ],
    [ "SolutionListOperations.c", "_solution_list_operations_8c_source.html", null ],
    [ "SolutionListOperations.h", "_solution_list_operations_8h.html", "_solution_list_operations_8h" ],
    [ "StructureDefinitions.h", "_structure_definitions_8h.html", "_structure_definitions_8h" ],
    [ "TrainAndTest.c", "_train_and_test_8c_source.html", null ],
    [ "TrainAndTest.h", "_train_and_test_8h.html", "_train_and_test_8h" ]
];