var searchData=
[
  ['score',['score',['../structcandidate_solution.html#aef160b7437d94056f1dc59646cd5b87d',1,'candidateSolution']]],
  ['size',['size',['../structcandidate_solution.html#a439227feff9d7f55384e8780cfc2eb82',1,'candidateSolution::size()'],['../structcandidate_list.html#a439227feff9d7f55384e8780cfc2eb82',1,'candidateList::size()']]]
];
