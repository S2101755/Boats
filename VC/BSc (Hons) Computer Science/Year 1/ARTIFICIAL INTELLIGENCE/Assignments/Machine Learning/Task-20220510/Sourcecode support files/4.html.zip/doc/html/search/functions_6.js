var searchData=
[
  ['scoreworkingcandidateontrainingset',['ScoreWorkingCandidateOnTrainingSet',['../_train_and_test_8h.html#af9c1232a844174a1f67ce0eb9694aa84',1,'TrainAndTest.c']]]
];
