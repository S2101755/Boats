var _rule_induction_definitions_8h =
[
    [ "rule", "structrule.html", "structrule" ],
    [ "false", "_rule_induction_definitions_8h.html#a65e9886d74aaee76545e83dd09011727", null ],
    [ "MAX_NUM_RULES", "_rule_induction_definitions_8h.html#af136dc74f657d663a83837b796be4c7d", null ],
    [ "N", "_rule_induction_definitions_8h.html#a0240ac851181b84ac374872dc5434ee4", null ],
    [ "NO_PREDICTION", "_rule_induction_definitions_8h.html#a66f8c8e93fd35596e7c4e91f53d661eb", null ],
    [ "NO_PREDICTION", "_rule_induction_definitions_8h.html#a66f8c8e93fd35596e7c4e91f53d661eb", null ],
    [ "NUM_FEATURES", "_rule_induction_definitions_8h.html#ac2bca8adbc07c70e5c38d1d34a5568bb", null ],
    [ "NUM_OPERATORS", "_rule_induction_definitions_8h.html#a538044ad08a6dd9927aa0fc47d4281d1", null ],
    [ "NUM_SAMPLES", "_rule_induction_definitions_8h.html#af0b23eedf2352de4c1eff77e1401730c", null ],
    [ "NUM_TEST_SAMPLES", "_rule_induction_definitions_8h.html#ab9abe082add4694caf047593554b104d", null ],
    [ "NUM_TRAINING_SAMPLES", "_rule_induction_definitions_8h.html#ae3f0081f58c8df0f6c55b3ca3b1268e9", null ],
    [ "SIZEOFSOLUTIONLIST", "_rule_induction_definitions_8h.html#aee7795481de30f64d6f5e10b43842e97", null ],
    [ "THRESHOLD_PRECISION", "_rule_induction_definitions_8h.html#aa46ca7830b25a19c8d2c456bac0c3cd6", null ],
    [ "true", "_rule_induction_definitions_8h.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7", null ],
    [ "UNUSED", "_rule_induction_definitions_8h.html#addf5ec070e9499d36b7f2009ce736076", null ],
    [ "VALUES_PER_RULE", "_rule_induction_definitions_8h.html#a28bc5594d8b5c5865a981eda7fe05dce", null ],
    [ "bool", "_rule_induction_definitions_8h.html#a1062901a7428fdd9c7f180f5e01ea056", null ],
    [ "operator", "_rule_induction_definitions_8h.html#aa5cd52a426f56a1c35b00d50ff3c8879", [
      [ "lessThan", "_rule_induction_definitions_8h.html#aa5cd52a426f56a1c35b00d50ff3c8879ab5e9f3312fc5c0b8de52d6b9e7d537d2", null ],
      [ "equals", "_rule_induction_definitions_8h.html#aa5cd52a426f56a1c35b00d50ff3c8879a544c77d4e9db935026f87d73ae9cd3dd", null ],
      [ "greaterThan", "_rule_induction_definitions_8h.html#aa5cd52a426f56a1c35b00d50ff3c8879a5abcb198fd75034ac882478e3e1f6513", null ]
    ] ]
];