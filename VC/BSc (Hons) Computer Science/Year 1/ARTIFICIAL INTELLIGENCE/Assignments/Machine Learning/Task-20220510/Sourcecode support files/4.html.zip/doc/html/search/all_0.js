var searchData=
[
  ['addworkingcandidatetoclosedlist',['AddWorkingCandidateToClosedList',['../_solution_list_operations_8h.html#af2297f7edb970fb15b55c64576eb9480',1,'SolutionListOperations.c']]],
  ['addworkingcandidatetoopenlist',['AddWorkingCandidateToOpenList',['../_solution_list_operations_8h.html#ab811e7114f2127e136c1dc5ed2af5e35',1,'SolutionListOperations.c']]]
];
