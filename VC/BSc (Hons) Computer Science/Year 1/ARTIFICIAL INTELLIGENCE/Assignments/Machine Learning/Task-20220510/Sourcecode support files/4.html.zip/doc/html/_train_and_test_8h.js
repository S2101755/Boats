var _train_and_test_8h =
[
    [ "rule", "structrule.html", "structrule" ],
    [ "_TrainAndTest", "_train_and_test_8h.html#abce40adcaa8ccde28850aff5511e636f", null ],
    [ "MAX_NUM_RULES", "_train_and_test_8h.html#af136dc74f657d663a83837b796be4c7d", null ],
    [ "N", "_train_and_test_8h.html#a0240ac851181b84ac374872dc5434ee4", null ],
    [ "NO_PREDICTION", "_train_and_test_8h.html#a66f8c8e93fd35596e7c4e91f53d661eb", null ],
    [ "NO_PREDICTION", "_train_and_test_8h.html#a66f8c8e93fd35596e7c4e91f53d661eb", null ],
    [ "NUM_FEATURES", "_train_and_test_8h.html#ac2bca8adbc07c70e5c38d1d34a5568bb", null ],
    [ "NUM_OPERATORS", "_train_and_test_8h.html#a538044ad08a6dd9927aa0fc47d4281d1", null ],
    [ "NUM_SAMPLES", "_train_and_test_8h.html#af0b23eedf2352de4c1eff77e1401730c", null ],
    [ "NUM_TEST_SAMPLES", "_train_and_test_8h.html#ab9abe082add4694caf047593554b104d", null ],
    [ "NUM_TRAINING_SAMPLES", "_train_and_test_8h.html#ae3f0081f58c8df0f6c55b3ca3b1268e9", null ],
    [ "THRESHOLD_PRECISION", "_train_and_test_8h.html#aa46ca7830b25a19c8d2c456bac0c3cd6", null ],
    [ "VALUES_PER_RULE", "_train_and_test_8h.html#a28bc5594d8b5c5865a981eda7fe05dce", null ],
    [ "operator", "_train_and_test_8h.html#aa5cd52a426f56a1c35b00d50ff3c8879", [
      [ "lessThan", "_train_and_test_8h.html#aa5cd52a426f56a1c35b00d50ff3c8879ab5e9f3312fc5c0b8de52d6b9e7d537d2", null ],
      [ "equals", "_train_and_test_8h.html#aa5cd52a426f56a1c35b00d50ff3c8879a544c77d4e9db935026f87d73ae9cd3dd", null ],
      [ "greaterThan", "_train_and_test_8h.html#aa5cd52a426f56a1c35b00d50ff3c8879a5abcb198fd75034ac882478e3e1f6513", null ]
    ] ],
    [ "ExtendWorkingCandidateByAddingRule", "_train_and_test_8h.html#ae23c4f21d92c343728aa12c8c0952827", null ],
    [ "GoalFound", "_train_and_test_8h.html#ad275fc6d5410358c6097101508a9a87c", null ],
    [ "GreedyConstructiveSearch", "_train_and_test_8h.html#a35663bd6382ea09ee4f976545c16301c", null ],
    [ "PredictClassFromRule", "_train_and_test_8h.html#a0a73d59b78f2a5b8ba5599f69e7dda19", null ],
    [ "predictLabel", "_train_and_test_8h.html#a158d2740807d74749a4583d7d401fd4b", null ],
    [ "prepareTrainingDataArrays", "_train_and_test_8h.html#ad2edb101ff48ec826704dc373efc686a", null ],
    [ "printWorkingCandidate", "_train_and_test_8h.html#a1ec0c3438a043f2cfc16a014d2a2a8b7", null ],
    [ "ScoreWorkingCandidateOnTrainingSet", "_train_and_test_8h.html#af9c1232a844174a1f67ce0eb9694aa84", null ],
    [ "StoreData", "_train_and_test_8h.html#aab55aca75bc98aa6345ff7ff52343cac", null ],
    [ "train", "_train_and_test_8h.html#ac4fd3e386abc86b08957b933dffa4e8a", null ]
];