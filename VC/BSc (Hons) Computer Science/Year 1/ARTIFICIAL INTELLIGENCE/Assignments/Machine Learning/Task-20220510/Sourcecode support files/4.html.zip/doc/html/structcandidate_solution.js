var structcandidate_solution =
[
    [ "score", "structcandidate_solution.html#aef160b7437d94056f1dc59646cd5b87d", null ],
    [ "size", "structcandidate_solution.html#a439227feff9d7f55384e8780cfc2eb82", null ],
    [ "variableValues", "structcandidate_solution.html#a9e61e35b326c4646ada6f4157b1855b0", null ]
];