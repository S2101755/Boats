var searchData=
[
  ['threshold',['threshold',['../structrule.html#a686599473d8ce395e95619896d88d539',1,'rule']]],
  ['train',['train',['../_train_and_test_8h.html#ac4fd3e386abc86b08957b933dffa4e8a',1,'TrainAndTest.c']]],
  ['trainandtest_2eh',['TrainAndTest.h',['../_train_and_test_8h.html',1,'']]]
];
