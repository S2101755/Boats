var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "ExampleData.h", "_example_data_8h_source.html", null ],
    [ "RuleInduction_main.c", "_rule_induction__main_8c_source.html", null ],
    [ "RuleInduction_SupportFunctions.c", "_rule_induction___support_functions_8c_source.html", null ],
    [ "RuleInduction_SupportFunctions.h", "_rule_induction___support_functions_8h_source.html", null ],
    [ "RuleInductionDefinitions.h", "_rule_induction_definitions_8h.html", "_rule_induction_definitions_8h" ],
    [ "SolutionListOperations.c", "_solution_list_operations_8c_source.html", null ],
    [ "SolutionListOperations.h", "_solution_list_operations_8h.html", "_solution_list_operations_8h" ],
    [ "StructureDefinitions.h", "_structure_definitions_8h.html", "_structure_definitions_8h" ]
];