var searchData=
[
  ['sizeofsolutionlist',['SIZEOFSOLUTIONLIST',['../_structure_definitions_8h.html#aee7795481de30f64d6f5e10b43842e97',1,'StructureDefinitions.h']]]
];
