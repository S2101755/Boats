var structrule =
[
    [ "comparison", "structrule.html#a1c1385e20b780ee1936e1e5a1cfe908b", null ],
    [ "prediction", "structrule.html#aeab877dc3fdedf5a7a6de8a5632bfb83", null ],
    [ "threshold", "structrule.html#a686599473d8ce395e95619896d88d539", null ],
    [ "variableAffected", "structrule.html#a7172407a07da51743953b74f4e483c8b", null ]
];