var indexSectionsWithContent =
{
  0: "aceglprstuv",
  1: "cr",
  2: "st",
  3: "acegprst",
  4: "clpstv",
  5: "su"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

