var searchData=
[
  ['cleancandidate',['CleanCandidate',['../_solution_list_operations_8h.html#ac6a5bab994eb479d61f83c349448760d',1,'SolutionListOperations.c']]],
  ['cleanlistsofsolutionstostart',['CleanListsOfSolutionsToStart',['../_solution_list_operations_8h.html#afaff8a05238b1a51aa8a7564b45c3738',1,'SolutionListOperations.c']]],
  ['cleanworkingcandidate',['CleanWorkingCandidate',['../_solution_list_operations_8h.html#acfe41a9bb2fbe291868e53d29e6cb8c1',1,'SolutionListOperations.c']]],
  ['copysolutionfromopenlistintoworkingcandidate',['CopySolutionFromOpenListIntoWorkingCandidate',['../_solution_list_operations_8h.html#a7a2e26dc7d112b4233b728f7fc3ee342',1,'SolutionListOperations.c']]]
];
