var _structure_definitions_8h =
[
    [ "candidateSolution", "structcandidate_solution.html", "structcandidate_solution" ],
    [ "candidateList", "structcandidate_list.html", "structcandidate_list" ],
    [ "BIG_DBL", "_structure_definitions_8h.html#abf327e24a52eeec36a84dacf6c997026", null ],
    [ "false", "_structure_definitions_8h.html#a65e9886d74aaee76545e83dd09011727", null ],
    [ "Generic_StructureDefinitions_h", "_structure_definitions_8h.html#a5d0e01e65cd7f14a92033a35fd995ce2", null ],
    [ "MAXVARS", "_structure_definitions_8h.html#a0879a0e632584a9a8bee5ebffab571ca", null ],
    [ "NOTFOUND", "_structure_definitions_8h.html#ad96490cc68537c8d1797ed2a62489836", null ],
    [ "SIZEOFSOLUTIONLIST", "_structure_definitions_8h.html#aee7795481de30f64d6f5e10b43842e97", null ],
    [ "true", "_structure_definitions_8h.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7", null ],
    [ "UNUSED", "_structure_definitions_8h.html#addf5ec070e9499d36b7f2009ce736076", null ],
    [ "bool", "_structure_definitions_8h.html#a1062901a7428fdd9c7f180f5e01ea056", null ]
];