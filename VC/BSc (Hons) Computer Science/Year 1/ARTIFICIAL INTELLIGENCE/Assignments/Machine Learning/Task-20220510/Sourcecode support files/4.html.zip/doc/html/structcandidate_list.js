var structcandidate_list =
[
    [ "listEntries", "structcandidate_list.html#ab974beb5a5a671632174c48785bccd7c", null ],
    [ "size", "structcandidate_list.html#a439227feff9d7f55384e8780cfc2eb82", null ]
];