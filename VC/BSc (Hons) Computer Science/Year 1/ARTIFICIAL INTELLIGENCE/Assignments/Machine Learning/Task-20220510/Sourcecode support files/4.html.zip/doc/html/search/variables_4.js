var searchData=
[
  ['threshold',['threshold',['../structrule.html#a686599473d8ce395e95619896d88d539',1,'rule']]]
];
