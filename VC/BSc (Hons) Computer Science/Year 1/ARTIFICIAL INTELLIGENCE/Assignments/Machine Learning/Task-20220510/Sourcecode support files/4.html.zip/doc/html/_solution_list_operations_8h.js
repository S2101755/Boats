var _solution_list_operations_8h =
[
    [ "SolutionListOperations_h", "_solution_list_operations_8h.html#a9bb35aee8771665fed73c4cc06273b26", null ],
    [ "AddSolutionPram1_ToListParam2", "_solution_list_operations_8h.html#aab9de6fd249c08a9e8082afbc0a361d3", null ],
    [ "AddWorkingCandidateToClosedList", "_solution_list_operations_8h.html#af2297f7edb970fb15b55c64576eb9480", null ],
    [ "AddWorkingCandidateToOpenList", "_solution_list_operations_8h.html#ab811e7114f2127e136c1dc5ed2af5e35", null ],
    [ "ChangeWorkingCandidateByReplaceValueinPlaceParam1_WithValueParam2", "_solution_list_operations_8h.html#ab118562edf8e78e0e5c688d765da43ce", null ],
    [ "CleanCandidate", "_solution_list_operations_8h.html#ac6a5bab994eb479d61f83c349448760d", null ],
    [ "CleanListsOfSolutionsToStart", "_solution_list_operations_8h.html#afaff8a05238b1a51aa8a7564b45c3738", null ],
    [ "CleanWorkingCandidate", "_solution_list_operations_8h.html#acfe41a9bb2fbe291868e53d29e6cb8c1", null ],
    [ "CopySolution", "_solution_list_operations_8h.html#a598418f340bf0a11786dce8836365af1", null ],
    [ "CopySolutionFromOpenListIntoWorkingCandidate", "_solution_list_operations_8h.html#a7a2e26dc7d112b4233b728f7fc3ee342", null ],
    [ "ExtendWorkingCandidateByAddingValue", "_solution_list_operations_8h.html#a772d5dadc98a4fbe52e53bd723812738", null ],
    [ "GetIndexOfWorkingCandidateInClosedList", "_solution_list_operations_8h.html#a5fd74a489fc6453b93e287ed9d37f059", null ],
    [ "GetIndexOfWorkingCandidateInOpenList", "_solution_list_operations_8h.html#acf84bdb62c45197c6d8c82d042b85e5b", null ],
    [ "GetIndexOfWorkingCandidateInThisList", "_solution_list_operations_8h.html#a8f398756346415d2d24f0213914d6fc7", null ],
    [ "PrintThisMessageAndExit", "_solution_list_operations_8h.html#a793ef952c5d67f28f8e3662892783112", null ],
    [ "RemoveFromListParam1_CandidateSolutionAtIndexParam2", "_solution_list_operations_8h.html#ae0e346a2a0a5c8d4de50f4c37d41d487", null ],
    [ "RemoveSolutionFromOpenList", "_solution_list_operations_8h.html#a209a2eb4c75a454f5f8997118e560e4e", null ]
];