import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) {
		
		 menu();
	}
		 public static void menu()	{
				Scanner buy = new Scanner (System.in);
				
				System.out.println("How many coconuts would you like to buy?");
				int coco1 = buy.nextInt();
				
				System.out.println("Choose your size of cocnut from \n1. Large (MVR 30) \n2. Medium (MVR 20) \n3. Small (MVR 12)");
				
				
				int price = buy.nextInt();
				switch (price)
				
			{
				case 1:
				{
					System.out.println("Please wait...");
					int sum1 = coco1 * 30;
					
					System.out.println("Your total is = " + sum1);
					
					System.out.println("Thank you for shopping with us!");
					String choice = buy.next();
					if (choice.equalsIgnoreCase("Yes"))
					{
						menu();
					}
					else
					{
						break;
					}
				}	
				
			//**********************************************************
				case 2:
				{
					System.out.println("Please wait...");
					int sum2 = coco1 * 20;
					
					System.out.println("Your total is = " + sum2);
					
					System.out.println("Thank you for shopping with us!");
					String choice = buy.next();
					if (choice.equalsIgnoreCase("Yes"))
					{
						menu();
					}
					else
					{
						break;
					}
				}	
			//***********************************************************
				
				case 3:
				{
					System.out.println("Please wait...");
					int sum3 = coco1 * 12;
					
					System.out.println("Your total is = " + sum3);
					
					System.out.println("Thank you for shopping with us!");
					String choice = buy.next();
					if (choice.equalsIgnoreCase("Yes"))
					{
						menu();
					}
					else
					{
						break;
					}
				}	
			}
		 }

}
