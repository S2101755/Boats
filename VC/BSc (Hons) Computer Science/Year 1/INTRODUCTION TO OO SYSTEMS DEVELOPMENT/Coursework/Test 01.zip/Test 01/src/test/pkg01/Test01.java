/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.pkg01;

import java.util.Scanner;
        
/**
 *
 * @author Shauzab Mufeed
 */
public class Test01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // My Code
        Scanner Calculator = new Scanner (System.in);
        // specify the integer values
        int n1, n2, n3;
        int sum = 0;
        // now print
        System.out.println("Enter your 1st number ");
        n1 = Calculator.nextInt();
        System.out.println("Enter your 2nd number ");
        n2 = Calculator.nextInt();
        System.out.println("Enter your 3rd number ");
        n3 = Calculator.nextInt();
        //print the total and average
        sum = (int) n1 + n2 + n3;
        System.out.println("Total = "+sum);
        System.out.println("Average = "+sum/3);
    }
    
}
