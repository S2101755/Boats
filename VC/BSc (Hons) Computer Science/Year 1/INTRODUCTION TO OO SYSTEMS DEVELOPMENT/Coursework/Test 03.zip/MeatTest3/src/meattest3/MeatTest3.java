package meattest3;
import java.io.*;
import java.util.*;
public class MeatTest3 {

    public static void main(String[] args) throws FileNotFoundException{
        //locate the file to scan/read
          File meatlist = new File ("Meat.txt");
          Scanner get = new Scanner (meatlist);
          readin(get);
    }
    
    private static void readin(Scanner get) {
        
        int m1;
        int m2;
        int m3;
        
        System.out.println("Welcome to THE MEAT shop!!!\n");
        System.out.println("Please find our meats below\n");
        do 
        {
            System.out.println("Name of the meat: "+get.next()); // read the string of the file
            m1 = get.nextInt(); // now declare the integer value of the file
            System.out.println("Price of the item = "+ m1); // pull out declared integer value from file
            get.hasNext();
            
            System.out.println("Name of the meat: "+get.next()); // read the string of the file
            m2 = get.nextInt(); // now declare the integer value of the file
            System.out.println("Price of the item = "+m2); // pull out declared integer value from file
            get.hasNext();
            
            System.out.println("Name of the meat: "+get.next()); // read the string of the file
            m3 = get.nextInt(); // now declare the integer value of the file
            System.out.println("Price of the item = "+m3); // pull out declared integer value from file
        }
        while (get.hasNext());
        
        Scanner in = new Scanner(System.in); // created new scanner for user input

        System.out.println("What is your meat of choice (1, 2, 3) \n ");
        int s = in.nextInt(); // declared new int value for user input
        
        while (true){
            
            // run 
        switch (s){ 
            
            // run user input in a switch case
            case 1:
                if (s == 1){
                System.out.println("How many do you want to purchase?");
                int man1 = in.nextInt();
                System.out.println("Your total billed amount is = " + "MVR "+m1*man1);
                System.out.println("Have a nice day!");
                }
               break;
            case 2:
                if (s == 2){
                System.out.println("How many do you want to purchase?");
                int man2 = in.nextInt();
                System.out.println("Your total billed amount is = " + "MVR "+m2*man2);
                System.out.println("Have a nice day!");
                }
               break;
            case 3:
                if (s == 3){
                System.out.println("How many do you want to purchase?");
                int man3 = in.nextInt();
                System.out.println("Your total billed amount is = " + "MVR "+m3*man3);
                System.out.println("Have a nice day!");
                }
                break;
                // break case and declare your default switch
            default:
                System.out.println("INVALID INPUT");
               }
        break;
        }    
    }
}