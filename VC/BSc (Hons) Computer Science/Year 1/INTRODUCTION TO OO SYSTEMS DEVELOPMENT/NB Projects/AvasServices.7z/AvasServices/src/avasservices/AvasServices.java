
package avasservices;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ShauXab
 */
public class AvasServices {

    /**
     * @param args the command line arguments
     */
    private static final ArrayList<CycleService> cyList = new ArrayList<>();
    private static final ArrayList<Customer> cusList = new ArrayList<>();
    private static final ArrayList<CurrSer> currSer = new ArrayList<>();
    private static final Scanner scan = new Scanner(System.in);
    
    
    public static void main(String[] args) {
 
    cyList.add(new CycleService("Honda","||\tZoomer x",100));
    cyList.add(new CycleService("Honda","||\tWave 125",120));
    cyList.add(new CycleService("Honda","||\tWave 150",130));
    cyList.add(new CycleService("Honda","||\tScoopy i",135));
    cyList.add(new CycleService("Honda","||\tAirBlade 125",125));
    cyList.add(new CycleService("Honda","||\tAirBlade 150",135));
    cyList.add(new CycleService("Suzuki","||\tGN 125\t",150));
    
    Boolean main = false;
    
    while (!main){
            System.out.println("==================================================================");
            System.out.println("<<<<<<<<<||||||\t WELCOME TO FEEL MOTOR SERVICES\t||||||>>>>>>>>>");
            System.out.println("==================================================================\n");
            System.out.println("Please enter your information to continnue");
            System.out.print("Full Name: ");
            String custName = scan.nextLine();
            
            System.out.println("Mobile Number: ");
            int custMNum = scan.nextInt();
            
            System.out.println("Current Address: ");
            scan.nextLine();
            String custAddress = scan.nextLine();
            
            System.out.println("Vehicle Registration Number (Motocycle board number): ");
            String boardNum = scan.nextLine();
            
            cusList.add(new Customer(custName, custMNum, custAddress, boardNum));
            System.out.println("Thank you!"); System.out.println("Welcome to Feel Motor Services");
            System.out.println("==================================================================\n");
            
            System.out.println("Please choose an option from below...\n");
            
            System.out.println("1 :\t \tMotocycle wash and maintenance \t\t:");
            System.out.println("2 :\t \tEngine related services \t\t:");
            System.out.println("3 :\t \tOther services \t\t\t\t:");
            System.out.println("4 :\t \tExit \t\t\t\t\t:\n");
            System.out.println("==================================================================\n");
            
            int choice = scan.nextInt();
            switch (choice){
                case 1:
                    Service();
            }
                
                    
                }
        
        }
    public static void Service() {
            Boolean servExit = false;
        while (!servExit) {
            System.out.println("==================================================================");
            System.out.println("\t\t***||MOTOCYCLE WASH AND MAINTENANCE||***");
            System.out.println("==================================================================\n");
            System.out.println("1 :\t \tWash without service \t\t\t:");
            System.out.println("2 :\t \tWash and full service \t\t\t:");
            System.out.println("3 :\t \tGo back \t\t\t\t:");
            System.out.println("==================================================================\n");

            int choice = scan.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("\tBRAND\t|| \tNAME\t \t||\tSERVICE PRICE");
                    System.out.println("==================================================================\n");
                    for (CycleService cyy : cyList) {
                        System.out.println("\t" + cyy.cycleBrand + "\t"+ cyy.cycleName + "\t"+ "||\t"+cyy.price + "\t\n");}
                    System.out.println("==================================================================");
                    System.out.println("Select your motorcycle from the list");
                    int moto = scan.nextInt();
                    
                    
                    int total = 0;
                    for (CurrSer ser : currSer) {
                        System.out.println(ser.cycleName + " | Price: " + ser.price);
                        total += ser.price;
                    }
                   
               
            }
        }
    }
    
    public static void CycleList() {
        for (CycleService cycle : cyList) {
            System.out.println((cyList.indexOf(cycle) + 1) + " - " + cycle.cycleName + " - " + cycle.cycleBrand);
            //CycleList();
        }
    }
    public static void CustList() {
        for (Customer cust : cusList) {
            System.out.println((cusList.indexOf(cust) + 01) + " > " + cust.custName);
            //CustList();
        }
    }
    
}
