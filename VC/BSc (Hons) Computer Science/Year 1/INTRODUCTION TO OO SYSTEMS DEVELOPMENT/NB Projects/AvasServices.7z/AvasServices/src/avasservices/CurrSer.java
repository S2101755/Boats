/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package avasservices;

/**
 *
 * @author Asus
 */
public class CurrSer {

    CurrSer(CycleService cycleName, CycleService price){
        this.cycleName = cycleName;
        this.price = price;
    }
   
    CycleService cycleName;
    CycleService price;
    
    int cprice;
    
}
