/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package feelburgercafe;

/**
 *
 * @author shifaz
 */
public class FoodItem {

    public FoodItem(String name, double price) {
        this.name = name;
        this.price = price;
    }
    
    String name;
    double price;
    
}