/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maleautogaraaju;

/**
 *
 * @author shifaz
 */
public class VehicleServices {
    
public VehicleServices(String service, double price) {
        this.service = service;
        this.price = price;
    }
    
    String service;
    double price;
    
}
