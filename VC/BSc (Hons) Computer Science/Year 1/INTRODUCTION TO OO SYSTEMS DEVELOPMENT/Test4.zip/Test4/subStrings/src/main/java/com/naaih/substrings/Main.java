package com.naaih.substrings;

public class Main {
    public static void main(String[] args) {
        String str1 = "caterpillars";;
        
        System.out.println("1: " + str1.substring(0,3));
        System.out.println("2: " + str1.substring(5,12));
        System.out.println("3: " + str1.substring(1,4));
    }
    
}
